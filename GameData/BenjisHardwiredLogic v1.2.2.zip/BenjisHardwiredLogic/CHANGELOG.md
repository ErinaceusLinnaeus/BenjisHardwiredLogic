## Changelog:
##### v1.2.2
##### MORE MESSAGING OPTIONS:
##### - Added a rare 4th Stage and a Spin-Motor Option for Igniting and Seperating
##### - Grammar update: Editor: Igniting -> Ignite
##### - Grammar update: Editor: Decoupling -> Decouple
##### - Grammar update: Messaging: Jettison -> Jettisoning
##### - RCS with its own correct grammar
##### v1.2.1
##### CHANGELOG & README:
##### - Added to the release zip
##### OnScreen messaging system:
##### - All messages are now schown in the upper center
##### - Messages can be turned off now, forgot to implement that earlier
##### v1.2
##### OnScreen messaging system:
##### - Can be turned off
##### - Shows 3 pre messages before decoupling and igniting at -10s, -5s and -2s
##### - Shows a message at decoupling, igniting and fairing separation
##### v1.1.1
##### -inflight PAW change: Circuits are: connected/disconnected instead of active?: true/false
##### v1.1
##### -enable/disable button to disable funcionality instead of 0.0s/0km
##### v1.0
##### -initial release
